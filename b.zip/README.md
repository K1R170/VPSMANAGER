# Instalar o script + atualizar os pacotes do sistema
`wget https://raw.githubusercontent.com/nexyssh/VPSMANAGER-FULL/script/Plus; chmod +x Plus; ./Plus`
